"""
ZclockID Enterprise Management Appliance - Self Services & Password Reset Router
Provides Self-Service Password Reset (SSPR) via Old Password, Email OTP, and SMS OTP,
as well as audit logging, month filtering, search, pagination, and CSV log exports.
"""

import os
import re
import csv
import io
import time
import json
import secrets
import sqlite3
from api.db.connection import get_db
import logging
import hmac
import hashlib
from pathlib import Path
from typing import Dict, Any, List, Optional
from datetime import datetime
from fastapi import APIRouter, HTTPException, Request, Response, status, UploadFile, File, Body, Depends
from fastapi.responses import PlainTextResponse

from api.core.config import DB_PATH, SAMBA_LDB_PATH, DATA_DIR, WEB_DIR
from api.core.security import get_ad_creds, validate_ad_password_complexity, hash_otp, verify_otp_hash, hash_reset_token, verify_reset_token_hash
from api.services.system_service import run_cmd, log_audit, get_primary_realm
from api.services.samdb_service import samdb_setpassword
from api.services.security_service import get_client_ip
from api.routers.registration import dispatch_sms, dispatch_email
from api.schemas.self_service_schema import (
    PasswordChangeOldRequest,
    PasswordResetOtpRequest,
    PasswordResetVerifyRequest,
    PasswordResetSettingsUpdate,
    TestSmsRequest
)

from api.routers.auth import require_role

logger = logging.getLogger("zclockid.self_service")
router = APIRouter(prefix="/api/v1/self-service", tags=["Self Services & Password Reset"], dependencies=[Depends(require_role("readonly"))])

def get_ad_base_dn() -> str:
    """Retrieves authoritative Active Directory base DN (e.g. DC=inet,DC=net)."""
    try:
        code, stdout, _ = run_cmd(["ldbsearch", "-H", str(SAMBA_LDB_PATH), "-b", "", "-s", "base", "defaultNamingContext"], timeout=5)
        if code == 0:
            for line in stdout.splitlines():
                if line.lower().startswith("defaultnamingcontext:"):
                    return line.split(":", 1)[1].strip()
    except Exception:
        pass
    realm = get_primary_realm()
    parts = realm.strip().lower().split(".")
    return ",".join([f"DC={p}" for p in parts if p])


def is_sms_gateway_configured(settings: dict) -> bool:
    """Returns True if a real (non-simulated) external SMS gateway is configured."""
    gw_type = (settings.get("sms_gateway_type") or "simulated").lower().strip()
    if gw_type == "simulated" or not gw_type:
        return False
    if gw_type == "webhook":
        return bool(settings.get("sms_gateway_url", "").strip())
    if gw_type == "twilio":
        return bool(settings.get("sms_gateway_url", "").strip() and settings.get("sms_api_key", "").strip())
    if gw_type in ("fast2sms", "msg91"):
        return bool(settings.get("sms_api_key", "").strip())
    return False


def is_smtp_configured(settings: dict) -> bool:
    """Returns True if SMTP email dispatch is actively enabled and configured."""
    return bool(settings.get("email_smtp_enabled") and settings.get("smtp_host", "").strip())


def rfc4515_escape(val: str) -> str:
    """Escapes characters in LDAP search filter strings per RFC 4515 (*, (, ), \\, NUL)."""
    if not val:
        return ""
    # Backslash must be escaped first to prevent double-escaping
    val = val.replace("\\", "\\5c")
    val = val.replace("\x00", "\\00")
    val = val.replace("*", "\\2a")
    val = val.replace("(", "\\28")
    val = val.replace(")", "\\29")
    return val


def validate_username_format(username: str) -> bool:
    """Rejects usernames that start with '-' or contain anything other than [A-Za-z0-9._@-]."""
    if not username or username.startswith("-"):
        return False
    return bool(re.match(r"^[A-Za-z0-9._@-]{1,64}$", username))


def is_privileged_account(account_name: str, admin_count: int = 0, member_of: Optional[List[str]] = None, base_dn: Optional[str] = None) -> bool:
    """
    Refuses SSPR for Administrator, krbtgt, Guest, adminCount=1, direct memberOf,
    or nested admin-group membership using LDAP filter (memberOf:1.2.840.113556.1.4.1941:=...).
    """
    name_lower = (account_name or "").lower().strip()
    if name_lower in ("administrator", "krbtgt", "guest"):
        return True
    if admin_count == 1:
        return True
    privileged_groups = {"domain admins", "enterprise admins", "schema admins", "administrators"}
    if member_of:
        for group in member_of:
            group_lower = group.lower()
            for pg in privileged_groups:
                if f"cn={pg}," in group_lower or group_lower.endswith(f"cn={pg}") or group_lower == pg:
                    return True

    # Detect nested admin-group membership via LDAP matching rule in chain (1.2.840.113556.1.4.1941)
    if account_name:
        b_dn = base_dn or get_ad_base_dn()
        escaped_user = rfc4515_escape(account_name.strip())
        nested_filter = (
            f"(&(objectClass=user)(sAMAccountName={escaped_user})"
            f"(|(memberOf:1.2.840.113556.1.4.1941:=CN=Domain Admins,CN=Users,{b_dn})"
            f"(memberOf:1.2.840.113556.1.4.1941:=CN=Enterprise Admins,CN=Users,{b_dn})"
            f"(memberOf:1.2.840.113556.1.4.1941:=CN=Schema Admins,CN=Users,{b_dn})"
            f"(memberOf:1.2.840.113556.1.4.1941:=CN=Administrators,CN=Builtin,{b_dn})))"
        )
        code, stdout, _ = run_cmd([
            "ldbsearch", "-H", str(SAMBA_LDB_PATH),
            nested_filter, "dn"
        ], timeout=5)
        if code == 0 and "dn: " in stdout:
            return True

    return False


def check_and_record_sspr_attempt(username: str, client_ip: str, action: str, max_daily_user: int, max_daily_ip: int):
    """Enforces max_daily_attempts per username and max_daily_attempts_per_ip per client IP across all SSPR actions."""
    cutoff = time.time() - 86400
    conn = get_db(DB_PATH)
    cursor = conn.cursor()
    cursor.execute("""
        CREATE TABLE IF NOT EXISTS sspr_attempts (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            username TEXT,
            ip_address TEXT,
            action TEXT,
            timestamp REAL
        )
    """)
    cursor.execute("CREATE INDEX IF NOT EXISTS idx_sspr_attempts ON sspr_attempts(timestamp, username, ip_address)")

    clean_user = (username or "").strip().lower()
    if clean_user and max_daily_user > 0:
        cursor.execute("SELECT COUNT(*) FROM sspr_attempts WHERE LOWER(username) = ? AND timestamp > ?", (clean_user, cutoff))
        user_attempts = cursor.fetchone()[0]
        if user_attempts >= max_daily_user:
            conn.close()
            log_audit("SSPR_RATE_LIMIT_EXCEEDED", username, "sspr", "BLOCKED", {"ip": client_ip, "action": action, "count": user_attempts, "max": max_daily_user})
            raise HTTPException(
                status_code=status.HTTP_429_TOO_MANY_REQUESTS,
                detail=f"Rate limit exceeded: maximum daily attempts ({max_daily_user}) reached for this account."
            )

    if client_ip and max_daily_ip > 0:
        cursor.execute("SELECT COUNT(*) FROM sspr_attempts WHERE ip_address = ? AND timestamp > ?", (client_ip, cutoff))
        ip_attempts = cursor.fetchone()[0]
        if ip_attempts >= max_daily_ip:
            conn.close()
            log_audit("SSPR_RATE_LIMIT_EXCEEDED", username, "sspr", "BLOCKED", {"ip": client_ip, "action": action, "count": ip_attempts, "max": max_daily_ip})
            raise HTTPException(
                status_code=status.HTTP_429_TOO_MANY_REQUESTS,
                detail=f"Rate limit exceeded: maximum daily attempts ({max_daily_ip}) reached from this IP address."
            )

    cursor.execute(
        "INSERT INTO sspr_attempts (username, ip_address, action, timestamp) VALUES (?, ?, ?, ?)",
        (clean_user, client_ip, action, time.time())
    )
    conn.commit()
    conn.close()


def get_sspr_settings() -> Dict[str, Any]:
    """Retrieves Self Service Password Reset configuration."""
    conn = get_db(DB_PATH)
    conn.row_factory = sqlite3.Row
    cursor = conn.cursor()
    cursor.execute("SELECT * FROM self_service_password_settings WHERE id = 1")
    row = cursor.fetchone()
    conn.close()

    if row:
        d = dict(row)
        if not d.get("max_daily_attempts_per_ip"):
            d["max_daily_attempts_per_ip"] = 50
        return d

    # Defaults
    return {
        "id": 1,
        "enabled": 1,
        "allow_old_password_reset": 1,
        "allow_email_reset": 1,
        "allow_otp_reset": 1,
        "min_password_length": 8,
        "require_complexity": 1,
        "otp_expiry_minutes": 10,
        "max_daily_attempts": 5,
        "max_daily_attempts_per_ip": 50,
        "email_smtp_enabled": 0,
        "smtp_host": "",
        "smtp_port": 587,
        "smtp_user": "",
        "smtp_pass": "",
        "smtp_from": "",
        "sms_gateway_type": "simulated",
        "sms_gateway_url": "",
        "sms_api_key": "",
        "sms_sender_id": "ZCLOCK",
        "sms_template": "Your ZclockID password reset verification code is {otp}. Valid for 10 minutes.",
        "updated_at": time.time()
    }


def lookup_ad_user(username: str) -> Dict[str, Any]:
    """Searches Active Directory (Samba LDB) for user account and contact attributes with RFC 4515 escaping."""
    clean_user = (username or "").strip()
    if not clean_user or not validate_username_format(clean_user):
        return {"found": False}

    escaped_user = rfc4515_escape(clean_user)

    # Query by sAMAccountName, userPrincipalName, or mail
    query = f"(&(objectClass=user)(!(objectClass=computer))(|(sAMAccountName={escaped_user})(userPrincipalName={escaped_user})(mail={escaped_user})))"
    code, stdout, stderr = run_cmd([
        "ldbsearch", "-H", str(SAMBA_LDB_PATH),
        query,
        "sAMAccountName", "mail", "mobile", "telephoneNumber", "userPrincipalName", "userAccountControl", "adminCount", "memberOf"
    ], timeout=10)

    if code != 0 or "dn: " not in stdout:
        return {"found": False}

    account_name = clean_user
    email = None
    mobile = None
    uac = 512
    admin_count = 0
    member_of: List[str] = []

    for line in stdout.splitlines():
        line = line.strip()
        if line.lower().startswith("samaccountname:"):
            account_name = line.split(":", 1)[1].strip()
        elif line.lower().startswith("mail:"):
            email = line.split(":", 1)[1].strip()
        elif line.lower().startswith("mobile:"):
            mobile = line.split(":", 1)[1].strip()
        elif line.lower().startswith("telephonenumber:") and not mobile:
            mobile = line.split(":", 1)[1].strip()
        elif line.lower().startswith("useraccountcontrol:"):
            try:
                uac = int(line.split(":", 1)[1].strip())
            except Exception:
                pass
        elif line.lower().startswith("admincount:"):
            try:
                admin_count = int(line.split(":", 1)[1].strip())
            except Exception:
                pass
        elif line.lower().startswith("memberof:"):
            member_of.append(line.split(":", 1)[1].strip())

    base_dn = get_ad_base_dn()
    is_disabled = bool(uac & 2)
    is_priv = is_privileged_account(account_name, admin_count, member_of, base_dn=base_dn)

    return {
        "found": True,
        "username": account_name,
        "email": email,
        "mobile": mobile,
        "is_disabled": is_disabled,
        "is_privileged": is_priv,
        "admin_count": admin_count,
        "member_of": member_of
    }


def mask_email(email: str) -> str:
    if not email or "@" not in email:
        return ""
    user, domain = email.split("@", 1)
    if len(user) <= 2:
        masked_user = user[0] + "*"
    else:
        masked_user = user[0] + ("*" * (len(user) - 2)) + user[-1]
    return f"{masked_user}@{domain}"


def mask_phone(phone: str) -> str:
    if not phone:
        return ""
    clean = re.sub(r"[^\d+]", "", phone)
    if len(clean) <= 5:
        return clean
    return clean[:3] + ("*" * (len(clean) - 6)) + clean[-3:]


# ==================== PUBLIC PORTAL ENDPOINTS ====================

@router.get("/password/config")
def get_public_password_config():
    """Returns SSPR public policy, supported methods, and primary domain name."""
    settings = get_sspr_settings()
    primary_realm = get_primary_realm()

    allow_email = bool(settings.get("allow_email_reset", 1) and is_smtp_configured(settings))
    allow_sms = bool(settings.get("allow_otp_reset", 1) and is_sms_gateway_configured(settings))

    return {
        "status": "success",
        "enabled": bool(settings.get("enabled", 1)),
        "allow_old_password_reset": bool(settings.get("allow_old_password_reset", 1)),
        "allow_email_reset": allow_email,
        "allow_otp_reset": allow_sms,
        "min_password_length": int(settings.get("min_password_length", 8)),
        "require_complexity": bool(settings.get("require_complexity", 1)),
        "primary_domain": primary_realm,
        "support_notice": "If your phone number and email are not registered, please contact your Domain Administrator."
    }


@router.post("/password/change-with-old")
def change_password_with_old(req: PasswordChangeOldRequest, request: Request):
    """Changes password when user knows their current Active Directory password."""
    settings = get_sspr_settings()
    if not settings.get("enabled", 1):
        raise HTTPException(status_code=403, detail="Self Service Password Reset is currently disabled by administrator.")
    if not settings.get("allow_old_password_reset", 1):
        raise HTTPException(status_code=403, detail="Direct password change using current password is not permitted.")

    client_ip = get_client_ip(request)
    clean_user = (req.username or "").strip()

    if not validate_username_format(clean_user):
        raise HTTPException(status_code=400, detail="Invalid username format. Username cannot start with '-' and can only contain letters, digits, '.', '_', '@', and '-'.")

    # Enforce daily attempt limit per username and per client IP across SSPR
    max_daily_user = int(settings.get("max_daily_attempts", 5) or 5)
    max_daily_ip = int(settings.get("max_daily_attempts_per_ip", 50) or 50)
    check_and_record_sspr_attempt(clean_user, client_ip, "change-with-old", max_daily_user, max_daily_ip)

    # Check if account is privileged
    if is_privileged_account(clean_user):
        conn = get_db(DB_PATH)
        cursor = conn.cursor()
        cursor.execute("""
            INSERT INTO self_service_password_logs (
                username, method, recipient, otp_code, otp_expires_at, status,
                ip_address, user_agent, created_at, completed_at, notes, failed_attempts
            ) VALUES (?, 'OLD_PASSWORD', 'Direct Authentication', NULL, NULL, 'FAILED', ?, ?, ?, ?, 'SSPR refused for privileged account', 0)
        """, (clean_user, client_ip, request.headers.get("User-Agent", ""), time.time(), time.time()))
        conn.commit()
        conn.close()
        log_audit("SSPR_PRIVILEGED_BLOCKED", clean_user, "sspr", "BLOCKED", {"ip": client_ip, "method": "OLD_PASSWORD"})
        raise HTTPException(status_code=403, detail="Self-service password change is not permitted for privileged administrative accounts.")

    # Look up user to resolve sAMAccountName if UPN or email entered
    user_info = lookup_ad_user(clean_user)
    if user_info.get("found"):
        if user_info.get("is_privileged"):
            conn = get_db(DB_PATH)
            cursor = conn.cursor()
            cursor.execute("""
                INSERT INTO self_service_password_logs (
                    username, method, recipient, otp_code, otp_expires_at, status,
                    ip_address, user_agent, created_at, completed_at, notes, failed_attempts
                ) VALUES (?, 'OLD_PASSWORD', 'Direct Authentication', NULL, NULL, 'FAILED', ?, ?, ?, ?, 'SSPR refused for privileged account', 0)
            """, (clean_user, client_ip, request.headers.get("User-Agent", ""), time.time(), time.time()))
            conn.commit()
            conn.close()
            log_audit("SSPR_PRIVILEGED_BLOCKED", clean_user, "sspr", "BLOCKED", {"ip": client_ip, "method": "OLD_PASSWORD"})
            raise HTTPException(status_code=403, detail="Self-service password change is not permitted for privileged administrative accounts.")
        clean_user = user_info["username"]

    # Check password complexity if required
    min_len = int(settings.get("min_password_length", 8))
    if len(req.new_password) < min_len:
        raise HTTPException(status_code=400, detail=f"New password must be at least {min_len} characters long.")

    if settings.get("require_complexity", 1):
        is_valid, msg = validate_ad_password_complexity(req.new_password)
        if not is_valid:
            raise HTTPException(status_code=400, detail=msg)

    # Use smbpasswd over localhost SAMR with old\nnew\nnew\n on stdin.
    # smbpasswd successfully allows changing expired passwords / passwords that must be changed on next login.
    cmd = ["smbpasswd", "-r", "127.0.0.1", "-U", clean_user, "-s"]
    input_data = f"{req.old_password}\n{req.new_password}\n{req.new_password}\n"
    code, stdout, stderr = run_cmd(cmd, timeout=15, input_data=input_data)

    conn = get_db(DB_PATH)
    cursor = conn.cursor()

    if code == 0:
        cursor.execute("""
            INSERT INTO self_service_password_logs (
                username, method, recipient, otp_code, otp_expires_at, status,
                ip_address, user_agent, created_at, completed_at, notes, failed_attempts
            ) VALUES (?, 'OLD_PASSWORD', 'Direct Authentication', NULL, NULL, 'COMPLETED', ?, ?, ?, ?, 'Password changed successfully', 0)
        """, (clean_user, client_ip, request.headers.get("User-Agent", ""), time.time(), time.time()))
        conn.commit()
        conn.close()

        log_audit("SSPR_PASSWORD_CHANGED", clean_user, "active_directory", "SUCCESS", {"method": "OLD_PASSWORD", "ip": client_ip})
        return {
            "status": "success",
            "message": "Password changed successfully! You can now log in with your new password."
        }
    else:
        err_msg = (stderr.strip() + " " + stdout.strip()).strip()
        if "Authentication failed" in err_msg or "wrong" in err_msg.lower() or "NT_STATUS_WRONG_PASSWORD" in err_msg or "NT_STATUS_LOGON_FAILURE" in err_msg:
            user_facing_err = "Authentication failed: Current password is incorrect."
        elif "check_password_restrictions" in err_msg or "NT_STATUS_PASSWORD_RESTRICTION" in err_msg or "violated" in err_msg.lower() or "length criteria" in err_msg.lower():
            user_facing_err = "The new password does not meet domain password policy (minimum password age, history, or complexity restrictions)."
        elif "NT_STATUS_ACCOUNT_DISABLED" in err_msg:
            user_facing_err = "This account has been disabled. Please contact an administrator."
        elif "NT_STATUS_ACCOUNT_LOCKED_OUT" in err_msg:
            user_facing_err = "This account is locked out. Please contact an administrator."
        elif "NT_STATUS_ACCOUNT_EXPIRED" in err_msg:
            user_facing_err = "This account has expired. Please contact an administrator."
        else:
            user_facing_err = f"Password change rejected: {err_msg}"

        cursor.execute("""
            INSERT INTO self_service_password_logs (
                username, method, recipient, otp_code, otp_expires_at, status,
                ip_address, user_agent, created_at, completed_at, notes, failed_attempts
            ) VALUES (?, 'OLD_PASSWORD', 'Direct Authentication', NULL, NULL, 'FAILED', ?, ?, ?, ?, ?, 0)
        """, (clean_user, client_ip, request.headers.get("User-Agent", ""), time.time(), time.time(), user_facing_err))
        conn.commit()
        conn.close()

        log_audit("SSPR_PASSWORD_FAILED", clean_user, "active_directory", "FAILED", {"method": "OLD_PASSWORD", "ip": client_ip, "error": user_facing_err})
        raise HTTPException(status_code=400, detail=user_facing_err)


@router.post("/password/request-otp")
def request_password_reset_otp(req: PasswordResetOtpRequest, request: Request):
    """Validates user in Active Directory and dispatches an OTP via Email or Mobile SMS."""
    settings = get_sspr_settings()
    if not settings.get("enabled", 1):
        raise HTTPException(status_code=403, detail="Self Service Password Reset is currently disabled by administrator.")

    clean_user = (req.username or "").strip()

    # Reject usernames that start with '-' or contain anything other than [A-Za-z0-9._@-]
    if not validate_username_format(clean_user):
        raise HTTPException(status_code=400, detail="Invalid username format. Username cannot start with '-' and can only contain letters, digits, '.', '_', '@', and '-'.")

    channel = (req.channel or "").lower().strip()
    if channel not in ("email", "sms"):
        raise HTTPException(status_code=400, detail="Invalid verification channel requested. Must be 'email' or 'sms'.")

    # Stop returning the code in the response: return 503 if channel not configured
    if channel == "email" and not is_smtp_configured(settings):
        raise HTTPException(status_code=503, detail="No verification channel configured.")
    if channel == "sms" and not is_sms_gateway_configured(settings):
        raise HTTPException(status_code=503, detail="No verification channel configured.")

    if channel == "email" and not settings.get("allow_email_reset", 1):
        raise HTTPException(status_code=403, detail="Password reset via Email is not enabled.")
    if channel == "sms" and not settings.get("allow_otp_reset", 1):
        raise HTTPException(status_code=403, detail="Password reset via Mobile SMS is not enabled.")

    client_ip = get_client_ip(request)

    # Rate limiting: enforce max_daily_attempts per username and max_daily_attempts_per_ip per client IP
    max_daily_user = int(settings.get("max_daily_attempts", 5) or 5)
    max_daily_ip = int(settings.get("max_daily_attempts_per_ip", 50) or 50)
    check_and_record_sspr_attempt(clean_user, client_ip, "request-otp", max_daily_user, max_daily_ip)

    # Generic response parameters (identical for existing and nonexistent users to prevent enumeration)
    generic_msg = "If an account matching the provided username exists, a verification code has been dispatched."
    generic_recipient = "registered email" if channel == "email" else "registered mobile"

    # Lookup user in AD
    user_info = lookup_ad_user(clean_user)

    # Determine eligibility without disclosing to client
    eligible = True
    ineligible_reason = ""

    if not user_info.get("found"):
        eligible = False
        ineligible_reason = f"Domain account '{clean_user}' not found in Active Directory."
    elif user_info.get("is_disabled"):
        eligible = False
        ineligible_reason = f"Account '{clean_user}' is disabled."
    elif user_info.get("is_privileged"):
        eligible = False
        ineligible_reason = f"Account '{clean_user}' is a privileged administrative account (SSPR refused)."
    else:
        if channel == "email":
            user_email = user_info.get("email")
            if not user_email or "@" not in user_email:
                eligible = False
                ineligible_reason = f"No email address registered for account '{clean_user}'."
        elif channel == "sms":
            user_mobile = user_info.get("mobile")
            if not user_mobile or len(re.sub(r'[^\d]', '', user_mobile)) < 7:
                eligible = False
                ineligible_reason = f"No valid mobile phone registered for account '{clean_user}'."

    conn = get_db(DB_PATH)
    cursor = conn.cursor()

    if not eligible:
        # Make the fake request for an ineligible user indistinguishable from a real one:
        # store it as PENDING_OTP with a random unusable hash, so wrong codes get the same "attempts remaining" and lock behaviour.
        unusable_otp = secrets.token_hex(32)
        unusable_hash = hash_otp(unusable_otp)
        expiry_min = int(settings.get("otp_expiry_minutes", 10))
        expires_at = time.time() + (expiry_min * 60)
        reset_token = secrets.token_urlsafe(32)
        token_hash = hash_reset_token(reset_token)

        cursor.execute("""
            INSERT INTO self_service_password_logs (
                username, method, recipient, otp_code, otp_expires_at, status,
                ip_address, user_agent, created_at, completed_at, notes, failed_attempts, reset_token_hash
            ) VALUES (?, ?, ?, ?, ?, 'PENDING_OTP', ?, ?, ?, NULL, ?, 0, ?)
        """, (
            clean_user,
            "EMAIL_OTP" if channel == "email" else "SMS_OTP",
            generic_recipient,
            unusable_hash,
            expires_at,
            client_ip,
            request.headers.get("User-Agent", ""),
            time.time(),
            f"[INELIGIBLE] {ineligible_reason}",
            token_hash
        ))
        conn.commit()
        conn.close()

        log_audit(
            "SSPR_OTP_REQUEST_REJECTED",
            clean_user,
            channel,
            "BLOCKED",
            {"reason": ineligible_reason, "ip": client_ip, "channel": channel}
        )

        return {
            "status": "otp_sent",
            "reset_token": reset_token,
            "username": clean_user,
            "channel": channel,
            "recipient_masked": generic_recipient,
            "message": generic_msg
        }

    # Eligible user: generate OTP, hash it with HMAC-SHA256, dispatch via channel
    real_username = user_info["username"]
    otp = f"{secrets.randbelow(900000) + 100000}"
    otp_hashed = hash_otp(otp)
    expiry_min = int(settings.get("otp_expiry_minutes", 10))
    expires_at = time.time() + (expiry_min * 60)
    reset_token = secrets.token_urlsafe(32)
    token_hash = hash_reset_token(reset_token)

    if channel == "email":
        user_email = user_info["email"]
        cursor.execute("""
            INSERT INTO self_service_password_logs (
                username, method, recipient, otp_code, otp_expires_at, status,
                ip_address, user_agent, created_at, completed_at, notes, failed_attempts, reset_token_hash
            ) VALUES (?, 'EMAIL_OTP', ?, ?, ?, 'PENDING_OTP', ?, ?, ?, NULL, 'Verification code dispatched to registered email', 0, ?)
        """, (real_username, user_email, otp_hashed, expires_at, client_ip, request.headers.get("User-Agent", ""), time.time(), token_hash))
        conn.commit()
        conn.close()

        email_body = f"Hello {real_username},\n\nA password reset request was initiated for your ZclockID account from IP {client_ip}.\n\nYour verification code is: {otp}\n\nThis code will expire in {expiry_min} minutes. If you did not request this, please contact your security administrator immediately."
        dispatch_email(user_email, "ZclockID Password Reset Verification Code", email_body, settings)

        log_audit("SSPR_OTP_SENT", real_username, "email", "SUCCESS", {"recipient": mask_email(user_email), "ip": client_ip})

        return {
            "status": "otp_sent",
            "reset_token": reset_token,
            "username": clean_user,
            "channel": "email",
            "recipient_masked": generic_recipient,
            "message": generic_msg
        }
    else:  # channel == "sms"
        user_mobile = user_info["mobile"]
        cursor.execute("""
            INSERT INTO self_service_password_logs (
                username, method, recipient, otp_code, otp_expires_at, status,
                ip_address, user_agent, created_at, completed_at, notes, failed_attempts, reset_token_hash
            ) VALUES (?, 'SMS_OTP', ?, ?, ?, 'PENDING_OTP', ?, ?, ?, NULL, 'Verification code dispatched to registered mobile', 0, ?)
        """, (real_username, user_mobile, otp_hashed, expires_at, client_ip, request.headers.get("User-Agent", ""), time.time(), token_hash))
        conn.commit()
        conn.close()

        sms_msg = settings.get("sms_template", "Your ZclockID password reset verification code is {otp}. Valid for 10 minutes.").replace("{otp}", otp).replace("{username}", real_username)
        dispatch_sms(user_mobile, sms_msg, settings)

        log_audit("SSPR_OTP_SENT", real_username, "sms", "SUCCESS", {"recipient": mask_phone(user_mobile), "ip": client_ip})

        return {
            "status": "otp_sent",
            "reset_token": reset_token,
            "username": clean_user,
            "channel": "sms",
            "recipient_masked": generic_recipient,
            "message": generic_msg
        }


@router.post("/password/verify-and-reset")
def verify_otp_and_reset_password(req: PasswordResetVerifyRequest, request: Request):
    """Verifies the dispatched OTP code and resets the user's password in Active Directory."""
    if req.reset_id is not None:
        raise HTTPException(status_code=400, detail="reset_id is no longer accepted. Please use reset_token.")

    settings = get_sspr_settings()
    if not settings.get("enabled", 1):
        raise HTTPException(status_code=403, detail="Self Service Password Reset is currently disabled by administrator.")

    client_ip = get_client_ip(request)
    clean_otp = (req.otp_code or "").strip()
    provided_token = (req.reset_token or "").strip()
    if not provided_token:
        raise HTTPException(status_code=400, detail="Missing required reset_token.")

    provided_token_hash = hash_reset_token(provided_token)

    conn = get_db(DB_PATH)
    conn.row_factory = sqlite3.Row
    cursor = conn.cursor()

    # Look up by reset_token_hash ONLY and take username from the stored row
    cursor.execute("""
        SELECT * FROM self_service_password_logs 
        WHERE reset_token_hash = ?
    """, (provided_token_hash,))
    log_entry = cursor.fetchone()

    if not log_entry or not secrets.compare_digest(log_entry["reset_token_hash"] or "", provided_token_hash):
        conn.close()
        raise HTTPException(status_code=404, detail="Invalid password reset request identifier.")

    log_id = log_entry["id"]
    target_user = log_entry["username"]

    # Enforce daily attempt limit per username and per client IP across SSPR
    max_daily_user = int(settings.get("max_daily_attempts", 5) or 5)
    max_daily_ip = int(settings.get("max_daily_attempts_per_ip", 50) or 50)
    check_and_record_sspr_attempt(target_user, client_ip, "verify-and-reset", max_daily_user, max_daily_ip)

    current_status = log_entry["status"]
    failed_attempts = int(log_entry["failed_attempts"] or 0)

    if current_status == "LOCKED":
        conn.close()
        raise HTTPException(status_code=400, detail="This reset request has been locked due to too many failed attempts.")

    if current_status != "PENDING_OTP":
        conn.close()
        raise HTTPException(status_code=400, detail="This reset request has already been used or has expired.")

    if time.time() > log_entry["otp_expires_at"]:
        cursor.execute("UPDATE self_service_password_logs SET status = 'EXPIRED' WHERE id = ?", (log_id,))
        conn.commit()
        conn.close()
        raise HTTPException(status_code=400, detail="Verification code has expired. Please request a new code.")

    # Validate OTP with HMAC-SHA256 comparison
    stored_hash = log_entry["otp_code"]
    if not verify_otp_hash(clean_otp, stored_hash):
        failed_attempts += 1
        new_status = "LOCKED" if failed_attempts >= 5 else "PENDING_OTP"
        cursor.execute("""
            UPDATE self_service_password_logs 
            SET failed_attempts = ?, status = ?, notes = notes || ' | Incorrect OTP attempt'
            WHERE id = ?
        """, (failed_attempts, new_status, log_id))
        conn.commit()
        conn.close()

        if failed_attempts >= 5:
            log_audit("SSPR_REQUEST_LOCKED", target_user, "sspr", "LOCKED", {"reset_id": log_id, "ip": client_ip, "attempts": failed_attempts})
            raise HTTPException(status_code=400, detail="Too many failed verification attempts. This request has been locked.")
        else:
            log_audit("SSPR_OTP_FAILED", target_user, "sspr", "FAILED", {"reset_id": log_id, "ip": client_ip, "attempts": failed_attempts})
            raise HTTPException(status_code=400, detail=f"Invalid verification code entered ({5 - failed_attempts} attempts remaining). Please try again.")

    # Ineligible fake request check (unusable OTP would never match, but safety check)
    notes = log_entry["notes"] or ""
    if notes.startswith("[INELIGIBLE]"):
        conn.close()
        raise HTTPException(status_code=400, detail="Invalid verification code entered. Please try again.")

    # Check if target account is privileged (post-OTP validation)
    if is_privileged_account(target_user):
        conn.close()
        raise HTTPException(status_code=403, detail="Self-service password reset is not permitted for privileged accounts.")

    # Look up user in AD to resolve canonical username and re-verify privileges
    user_info = lookup_ad_user(target_user)
    if not user_info.get("found"):
        conn.close()
        raise HTTPException(status_code=400, detail="Unable to process password reset for this account.")
    if user_info.get("is_privileged"):
        conn.close()
        raise HTTPException(status_code=403, detail="Self-service password reset is not permitted for privileged accounts.")

    canonical_user = user_info["username"]

    # Validate password rules
    min_len = int(settings.get("min_password_length", 8))
    if len(req.new_password) < min_len:
        conn.close()
        raise HTTPException(status_code=400, detail=f"New password must be at least {min_len} characters long.")

    if settings.get("require_complexity", 1):
        is_valid, msg = validate_ad_password_complexity(req.new_password)
        if not is_valid:
            conn.close()
            raise HTTPException(status_code=400, detail=msg)

    # Use in-process SamDB to set the password without CLI arguments
    try:
        samdb_setpassword(canonical_user, req.new_password)
    except Exception as e:
        err_msg = str(e)
        cursor.execute("""
            UPDATE self_service_password_logs 
            SET status = 'FAILED', notes = ? 
            WHERE id = ?
        """, (f"Active Directory reset failed: {err_msg}", log_id))
        conn.commit()
        conn.close()
        raise HTTPException(status_code=400, detail=f"Failed to set new password in Active Directory: {err_msg}")

    # Mark as completed
    cursor.execute("""
        UPDATE self_service_password_logs 
        SET status = 'COMPLETED', completed_at = ?, notes = 'Password reset completed via OTP'
        WHERE id = ?
    """, (time.time(), log_id))
    conn.commit()
    conn.close()

    log_audit("SSPR_PASSWORD_RESET_SUCCESS", canonical_user, "active_directory", "SUCCESS", {"method": log_entry["method"], "ip": client_ip})



    return {
        "status": "success",
        "message": "Your password has been reset successfully! You can now log in with your new password."
    }


# ==================== ADMINISTRATOR MANAGEMENT & LOGS ====================

@router.get("/password/settings")
def get_password_reset_settings():
    """Returns administrator settings for Self Service Password Reset."""
    settings = get_sspr_settings()
    return {"status": "success", "settings": settings}


@router.post("/password/settings")
def update_password_reset_settings(req: PasswordResetSettingsUpdate):
    """Updates administrator settings for Self Service Password Reset."""
    conn = get_db(DB_PATH)
    cursor = conn.cursor()

    cursor.execute("""
        UPDATE self_service_password_settings
        SET enabled = ?,
            allow_old_password_reset = ?,
            allow_email_reset = ?,
            allow_otp_reset = ?,
            min_password_length = ?,
            require_complexity = ?,
            otp_expiry_minutes = ?,
            max_daily_attempts = ?,
            max_daily_attempts_per_ip = ?,
            email_smtp_enabled = ?,
            smtp_host = ?,
            smtp_port = ?,
            smtp_user = ?,
            smtp_pass = ?,
            smtp_from = ?,
            sms_gateway_type = ?,
            sms_gateway_url = ?,
            sms_api_key = ?,
            sms_sender_id = ?,
            sms_template = ?,
            updated_at = ?
        WHERE id = 1
    """, (
        1 if req.enabled else 0,
        1 if req.allow_old_password_reset else 0,
        1 if req.allow_email_reset else 0,
        1 if req.allow_otp_reset else 0,
        req.min_password_length,
        1 if req.require_complexity else 0,
        req.otp_expiry_minutes,
        req.max_daily_attempts,
        req.max_daily_attempts_per_ip,
        1 if req.email_smtp_enabled else 0,
        req.smtp_host.strip(),
        req.smtp_port,
        req.smtp_user.strip(),
        req.smtp_pass.strip(),
        req.smtp_from.strip(),
        req.sms_gateway_type.strip(),
        req.sms_gateway_url.strip(),
        req.sms_api_key.strip(),
        req.sms_sender_id.strip(),
        req.sms_template.strip(),
        time.time()
    ))
    conn.commit()
    conn.close()

    log_audit("SSPR_SETTINGS_UPDATED", "admin", "appliance", "SUCCESS", {})
    return {"status": "success", "message": "Self Service Password Reset settings updated successfully."}


@router.get("/password/logs")
def get_password_reset_logs(
    month: Optional[str] = None,
    status_filter: Optional[str] = None,
    search: Optional[str] = None,
    limit: Optional[int] = None
):
    """Returns password reset logs with filtering by month, status, and search query."""
    from api.services.log_retention_service import get_log_retention_settings
    if limit is None or limit <= 0:
        limit = int(get_log_retention_settings().get("self_service_ui_fetch_limit", 500) or 500)
    conn = get_db(DB_PATH)
    conn.row_factory = sqlite3.Row
    cursor = conn.cursor()

    query = "SELECT * FROM self_service_password_logs WHERE 1=1"
    params = []

    if status_filter and status_filter.lower() != "all":
        query += " AND status = ?"
        params.append(status_filter.upper())

    if search and search.strip():
        term = f"%{search.strip().lower()}%"
        query += " AND (LOWER(username) LIKE ? OR LOWER(recipient) LIKE ? OR LOWER(ip_address) LIKE ? OR LOWER(method) LIKE ?)"
        params.extend([term, term, term, term])

    query += " ORDER BY created_at DESC LIMIT ?"
    params.append(limit)
    cursor.execute(query, params)
    rows = cursor.fetchall()

    logs = []
    available_months = set()
    total_completed = 0
    total_failed = 0

    for r in rows:
        d = dict(r)
        d.pop("otp_code", None)  # Redact OTP hash from admin log output
        ts = d.get("created_at") or time.time()
        m_str = datetime.fromtimestamp(ts).strftime("%Y-%m")
        available_months.add(m_str)

        if d.get("status") == "COMPLETED":
            total_completed += 1
        elif d.get("status") in ["FAILED", "EXPIRED"]:
            total_failed += 1

        # Apply in-memory month filter if specified
        if month and month.lower() != "all" and m_str != month:
            continue

        logs.append(d)

    conn.close()

    sorted_months = sorted(list(available_months), reverse=True)

    return {
        "count": len(logs),
        "total_completed": total_completed,
        "total_failed": total_failed,
        "available_months": sorted_months,
        "logs": logs
    }


@router.get("/password/logs/export")
def export_password_reset_logs_csv(
    method: Optional[str] = None,
    status: Optional[str] = None,
    month: Optional[str] = None,
    search: Optional[str] = None
):
    """Generates a downloadable CSV export of all Self Service Password Reset logs."""
    conn = get_db(DB_PATH)
    conn.row_factory = sqlite3.Row
    cursor = conn.cursor()

    cursor.execute("SELECT * FROM self_service_password_logs ORDER BY created_at DESC")
    rows = cursor.fetchall()
    conn.close()

    output = io.StringIO()
    writer = csv.writer(output)
    writer.writerow(["ID", "Username", "Method", "Recipient", "Status", "IP Address", "Created At", "Completed At", "Notes"])

    for r in rows:
        d = dict(r)
        ts = d.get("created_at") or 0
        m_str = datetime.fromtimestamp(ts).strftime("%Y-%m") if ts else ""
        if month and month.lower() != "all" and m_str != month:
            continue

        if method and method.lower() != "all" and d.get("method") != method:
            continue

        if status and status.lower() != "all" and d.get("status") != status:
            continue

        if search and search.strip():
            term = search.strip().lower()
            haystack = f"{d.get('username') or ''} {d.get('recipient') or ''} {d.get('ip_address') or ''} {d.get('notes') or ''}".lower()
            if term not in haystack:
                continue

        created_fmt = datetime.fromtimestamp(ts).strftime("%Y-%m-%d %H:%M:%S") if ts else "-"
        comp_ts = d.get("completed_at")
        completed_fmt = datetime.fromtimestamp(comp_ts).strftime("%Y-%m-%d %H:%M:%S") if comp_ts else "-"

        writer.writerow([
            d["id"],
            d["username"],
            d["method"],
            d.get("recipient", "-"),
            d["status"],
            d.get("ip_address", "-"),
            created_fmt,
            completed_fmt,
            d.get("notes", "")
        ])

    csv_data = output.getvalue()
    filename = f"zclockid-password-resets-{month or 'all'}.csv"
    return Response(
        content=csv_data,
        media_type="text/csv",
        headers={"Content-Disposition": f"attachment; filename={filename}"}
    )


@router.get("/registrations/export")
def export_registration_logs_csv(
    status_filter: Optional[str] = None,
    month: Optional[str] = None,
    search: Optional[str] = None
):
    """Generates a downloadable CSV export of all Self-Registration requests."""
    conn = get_db(DB_PATH)
    conn.row_factory = sqlite3.Row
    cursor = conn.cursor()

    cursor.execute("SELECT * FROM self_registrations ORDER BY created_at DESC")
    rows = cursor.fetchall()
    conn.close()

    output = io.StringIO()
    writer = csv.writer(output)
    writer.writerow(["ID", "Username", "Full Name", "Email", "Mobile", "Department", "Status", "IP Address", "Created At", "Approved At", "Approved By", "Notes"])

    for r in rows:
        d = dict(r)
        ts = d.get("created_at") or 0
        m_str = datetime.fromtimestamp(ts).strftime("%Y-%m") if ts else ""
        if month and month.lower() != "all" and m_str != month:
            continue

        if status_filter and status_filter.lower() != "all" and d.get("status") != status_filter:
            continue

        if search and search.strip():
            term = search.strip().lower()
            haystack = f"{d.get('username') or ''} {d.get('given_name') or ''} {d.get('surname') or ''} {d.get('email') or ''} {d.get('mobile') or ''} {d.get('department') or ''}".lower()
            if term not in haystack:
                continue

        created_fmt = datetime.fromtimestamp(ts).strftime("%Y-%m-%d %H:%M:%S") if ts else "-"
        app_ts = d.get("approved_at")
        approved_fmt = datetime.fromtimestamp(app_ts).strftime("%Y-%m-%d %H:%M:%S") if app_ts else "-"

        full_name = f"{d.get('given_name') or ''} {d.get('surname') or ''}".strip()

        writer.writerow([
            d["id"],
            d["username"],
            full_name,
            d.get("email", "-"),
            d.get("mobile", "-"),
            d.get("department", "-"),
            d["status"],
            d.get("ip_address", "-"),
            created_fmt,
            approved_fmt,
            d.get("approved_by", "-"),
            d.get("notes", "")
        ])

    csv_data = output.getvalue()
    filename = f"zclockid-registrations-{month or 'all'}.csv"
    return Response(
        content=csv_data,
        media_type="text/csv",
        headers={"Content-Disposition": f"attachment; filename={filename}"}
    )


@router.post("/test-sms")
def test_sms_gateway(req: TestSmsRequest):
    """Dispatches a one-off test SMS using the provided gateway settings before or after saving."""
    test_otp = "123456"
    msg = (req.sms_template or "Your ZclockID verification code is {otp}.").replace("{otp}", test_otp).replace("{username}", "ZclockID-Test")
    settings_dict = {
        "sms_gateway_type": req.sms_gateway_type,
        "sms_gateway_url": req.sms_gateway_url,
        "sms_api_key": req.sms_api_key,
        "sms_sender_id": req.sms_sender_id
    }
    ok, details = dispatch_sms(req.mobile.strip(), msg, settings_dict)
    if not ok:
        raise HTTPException(status_code=400, detail=f"SMS Gateway test failed: {details}")
    return {"status": "success", "message": f"Test SMS sent successfully to {req.mobile}. Gateway Response: {details}"}


# ==================== CUSTOM PORTAL HTML TEMPLATES & ASSETS (PFSENSE STYLE) ====================

PORTAL_DIR = DATA_DIR / "portals"
PORTAL_ASSETS_DIR = PORTAL_DIR / "assets"

_PORTAL_MAP = {
    "registration": {
        "filename": "register.html",
        "example_name": "zclockid-register-example.html",
        "table": "self_registration_settings",
        "label": "Self-Registration Portal"
    },
    "password": {
        "filename": "password-reset.html",
        "example_name": "zclockid-password-reset-example.html",
        "table": "self_service_password_settings",
        "label": "Self-Service Password Portal"
    }
}


def _get_portal_meta(portal_type: str) -> Dict[str, str]:
    pt = portal_type.lower().strip()
    if pt not in _PORTAL_MAP:
        raise HTTPException(status_code=400, detail="Invalid portal type. Must be 'registration' or 'password'.")
    return _PORTAL_MAP[pt]


def _list_portal_assets() -> List[Dict[str, Any]]:
    PORTAL_ASSETS_DIR.mkdir(parents=True, exist_ok=True)
    items = []
    for f in sorted(PORTAL_ASSETS_DIR.iterdir(), key=lambda p: p.name.lower()):
        if f.is_file():
            st = f.stat()
            items.append({
                "filename": f.name,
                "size": st.st_size,
                "url": f"/portal-assets/{f.name}",
                "updated_at": st.st_mtime
            })
    return items


@router.get("/portal-template/{portal_type}/status")
def get_portal_template_status(portal_type: str):
    """Returns custom portal HTML activation state, custom file metadata, and uploaded logo assets."""
    meta = _get_portal_meta(portal_type)
    PORTAL_DIR.mkdir(parents=True, exist_ok=True)
    custom_path = PORTAL_DIR / meta["filename"]

    conn = get_db(DB_PATH)
    conn.row_factory = sqlite3.Row
    cursor = conn.cursor()
    cursor.execute(f"SELECT use_custom_html, custom_html_updated_at FROM {meta['table']} WHERE id = 1")
    row = cursor.fetchone()
    conn.close()

    use_custom = bool(row["use_custom_html"]) if row and "use_custom_html" in row.keys() else False
    db_updated = row["custom_html_updated_at"] if row and "custom_html_updated_at" in row.keys() else None

    has_custom = custom_path.exists() and custom_path.is_file()
    return {
        "status": "success",
        "portal_type": portal_type,
        "use_custom_html": use_custom and has_custom,
        "has_custom_file": has_custom,
        "custom_file_size": custom_path.stat().st_size if has_custom else 0,
        "custom_html_updated_at": custom_path.stat().st_mtime if has_custom else db_updated,
        "assets": _list_portal_assets()
    }


@router.get("/portal-template/{portal_type}/example")
def download_example_portal_template(portal_type: str):
    """Generates and downloads the commented example HTML template for pfSense-style customization."""
    meta = _get_portal_meta(portal_type)
    src_path = WEB_DIR / meta["filename"]
    if not src_path.exists():
        raise HTTPException(status_code=404, detail=f"Built-in template '{meta['filename']}' not found.")

    html_content = src_path.read_text(encoding="utf-8")

    header_comment = (
        f"<!-- =========================================================================\n"
        f"     ZCLOCKID CUSTOM {meta['label'].upper()} TEMPLATE (EXAMPLE)\n"
        f"     \n"
        f"     How to customize (pfSense Captive Portal Style):\n"
        f"     1. Upload your company logo/images under 'Portal Assets' in Settings\n"
        f"        (they are served from /portal-assets/<filename>).\n"
        f"     2. Add your <img src=\"/portal-assets/your-logo.png\"> or custom CSS,\n"
        f"        headings, colors, and corporate footer text below.\n"
        f"     3. Keep the form input IDs and /api/v1/... fetch() calls intact so\n"
        f"        Active Directory & OTP verification continue working.\n"
        f"     4. Upload this customized .html file in ZclockID Settings.\n"
        f"     ========================================================================= -->\n"
    )

    logo_hint = (
        "        <!-- Header (CUSTOMIZE LOGO, TITLE, AND SUBTITLE BELOW) -->\n"
        "        <!-- Example Organization Logo (upload your image under Portal Assets first):\n"
        "        <div class=\"text-center mb-2\">\n"
        "            <img src=\"/portal-assets/company-logo.png\" alt=\"Company Logo\" class=\"h-14 mx-auto object-contain\">\n"
        "        </div>\n"
        "        -->"
    )

    customized = html_content.replace("        <!-- Header -->", logo_hint, 1)
    final_html = header_comment + customized

    return Response(
        content=final_html,
        media_type="text/html",
        headers={"Content-Disposition": f"attachment; filename={meta['example_name']}"}
    )


@router.post("/portal-template/{portal_type}/upload")
async def upload_custom_portal_template(portal_type: str, file: UploadFile = File(...)):
    """Uploads and activates a custom HTML template in persistent DATA_DIR storage."""
    meta = _get_portal_meta(portal_type)
    fname = (file.filename or "").lower()
    if not fname.endswith((".html", ".htm")):
        raise HTTPException(status_code=400, detail="Only .html or .htm template files are accepted.")

    raw = await file.read()
    if len(raw) > 2 * 1024 * 1024:
        raise HTTPException(status_code=400, detail="HTML file exceeds 2 MB size limit.")
    if len(raw) < 20:
        raise HTTPException(status_code=400, detail="Uploaded HTML file appears to be empty.")

    try:
        decoded = raw.decode("utf-8")
    except UnicodeDecodeError:
        raise HTTPException(status_code=400, detail="HTML file must be UTF-8 encoded.")

    lower_html = decoded.lower()
    if "<html" not in lower_html and "<body" not in lower_html and "<form" not in lower_html:
        raise HTTPException(status_code=400, detail="Invalid HTML template: missing <html>, <body>, or <form> tags.")

    PORTAL_DIR.mkdir(parents=True, exist_ok=True)
    dest = PORTAL_DIR / meta["filename"]
    dest.write_text(decoded, encoding="utf-8")

    now_ts = time.time()
    conn = get_db(DB_PATH)
    cursor = conn.cursor()
    cursor.execute(
        f"UPDATE {meta['table']} SET use_custom_html = 1, custom_html_updated_at = ? WHERE id = 1",
        (now_ts,)
    )
    conn.commit()
    conn.close()

    log_audit("PORTAL_CUSTOM_HTML_UPLOADED", "admin", portal_type, "SUCCESS", {
        "filename": file.filename,
        "bytes": len(raw)
    })

    return {
        "status": "success",
        "portal_type": portal_type,
        "use_custom_html": True,
        "size": len(raw),
        "message": f"Custom {meta['label']} uploaded and activated successfully."
    }


@router.post("/portal-template/{portal_type}/toggle")
def toggle_custom_portal_template(portal_type: str, payload: Dict[str, Any] = Body(...)):
    """Enables or disables custom HTML template override (falling back to built-in page when disabled)."""
    meta = _get_portal_meta(portal_type)
    enable = bool(payload.get("use_custom_html", False))
    custom_path = PORTAL_DIR / meta["filename"]

    if enable and not custom_path.exists():
        raise HTTPException(status_code=400, detail="No custom HTML file has been uploaded yet. Please upload an HTML file first.")

    conn = get_db(DB_PATH)
    cursor = conn.cursor()
    cursor.execute(f"UPDATE {meta['table']} SET use_custom_html = ? WHERE id = 1", (1 if enable else 0,))
    conn.commit()
    conn.close()

    log_audit("PORTAL_CUSTOM_HTML_TOGGLED", "admin", portal_type, "SUCCESS", {"use_custom_html": enable})
    return {
        "status": "success",
        "use_custom_html": enable,
        "message": f"Custom HTML template {'enabled' if enable else 'disabled (using built-in default)'}."
    }


@router.delete("/portal-template/{portal_type}")
def reset_custom_portal_template(portal_type: str):
    """Deletes custom uploaded HTML file and reverts to ZclockID built-in default template."""
    meta = _get_portal_meta(portal_type)
    custom_path = PORTAL_DIR / meta["filename"]
    if custom_path.exists():
        custom_path.unlink()

    conn = get_db(DB_PATH)
    cursor = conn.cursor()
    cursor.execute(f"UPDATE {meta['table']} SET use_custom_html = 0, custom_html_updated_at = NULL WHERE id = 1")
    conn.commit()
    conn.close()

    log_audit("PORTAL_CUSTOM_HTML_RESET", "admin", portal_type, "SUCCESS", {})
    return {
        "status": "success",
        "use_custom_html": False,
        "message": f"Reverted {meta['label']} to built-in default template."
    }


@router.get("/portal-assets")
def list_portal_assets_endpoint():
    """Lists all uploaded branding logos/images/CSS available at /portal-assets/."""
    return {"status": "success", "assets": _list_portal_assets()}


@router.post("/portal-assets/upload")
async def upload_portal_asset(file: UploadFile = File(...)):
    """Uploads a branding asset (PNG, JPG, SVG, WEBP, ICO, CSS) to persistent storage."""
    orig_name = Path(file.filename or "asset").name
    safe_name = re.sub(r"[^a-zA-Z0-9._-]", "_", orig_name)
    allowed_exts = (".png", ".jpg", ".jpeg", ".gif", ".svg", ".webp", ".ico", ".css")
    if not safe_name.lower().endswith(allowed_exts):
        raise HTTPException(status_code=400, detail=f"Unsupported file type. Allowed: {', '.join(allowed_exts)}")

    raw = await file.read()
    if len(raw) > 5 * 1024 * 1024:
        raise HTTPException(status_code=400, detail="Asset file exceeds 5 MB limit.")
    if len(raw) == 0:
        raise HTTPException(status_code=400, detail="Uploaded file is empty.")

    PORTAL_ASSETS_DIR.mkdir(parents=True, exist_ok=True)
    dest = PORTAL_ASSETS_DIR / safe_name
    dest.write_bytes(raw)

    log_audit("PORTAL_ASSET_UPLOADED", "admin", safe_name, "SUCCESS", {"bytes": len(raw)})
    return {
        "status": "success",
        "filename": safe_name,
        "size": len(raw),
        "url": f"/portal-assets/{safe_name}",
        "message": f"Asset '{safe_name}' uploaded. Reference it in HTML as /portal-assets/{safe_name}"
    }


@router.delete("/portal-assets/{filename}")
def delete_portal_asset(filename: str):
    """Deletes an uploaded portal branding asset."""
    safe_name = Path(filename).name
    PORTAL_ASSETS_DIR.mkdir(parents=True, exist_ok=True)
    target = (PORTAL_ASSETS_DIR / safe_name).resolve()
    if target.parent != PORTAL_ASSETS_DIR.resolve():
        raise HTTPException(status_code=400, detail="Invalid filename.")
    if not target.exists():
        raise HTTPException(status_code=404, detail="Asset not found.")

    target.unlink()
    log_audit("PORTAL_ASSET_DELETED", "admin", safe_name, "SUCCESS", {})
    return {"status": "success", "message": f"Asset '{safe_name}' deleted."}


